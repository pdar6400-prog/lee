import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
  Linking,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons, Feather, FontAwesome5 } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSpring,
  Easing,
  FadeInDown,
  FadeIn,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useColors } from '@/hooks/useColors';

const GITHUB_KEYS_URL =
  'https://raw.githubusercontent.com/pdar6400-prog/fox/main/keys.txt';

const FIXED_PORTAL_URL =
  'https://portal-as.ruijienetworks.com/api/auth/wifidog?stage=portal&gw_id=984a6b458027&gw_sn=H1T078800132C&gw_address=192.168.110.1&gw_port=2060&ip=192.168.110.142&mac=ca:51:aa:ff:b8:51&slot_num=33&nasip=192.168.1.161&ssid=VLAN233&ustate=0&mac_req=1&url=http%3A%2F%2F192.168.0.1%2F&chap_id=%5C016&chap_challenge=%5C135%5C061%5C367%5C376%5C225%5C324%5C217%5C041%5C213%5C145%5C002%5C251%5C074%5C104%5C267%5C152';

type KeyStatus = 'idle' | 'checking' | 'valid' | 'invalid';
type DetectStatus = 'idle' | 'detecting' | 'found' | 'failed';

function buildPortalUrl(macAddr: string, gwIp: string): string {
  const url = new URL(FIXED_PORTAL_URL);
  url.searchParams.set('mac', macAddr);
  url.searchParams.set('gw_address', gwIp);
  url.searchParams.set('nasip', gwIp);
  return url.toString();
}

function generateVipId(): string {
  const num = Math.floor(Math.random() * 999999)
    .toString()
    .padStart(6, '0');
  return `VIP-${num}`;
}

// Glow animation component
function GlowDot({ color }: { color: string }) {
  const opacity = useSharedValue(0.3);
  useEffect(() => {
    opacity.value = withRepeat(
      withTiming(1, { duration: 800, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
  }, []);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      style={[{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }, style]}
    />
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const [vipId, setVipId] = useState<string>('');
  const [keyInput, setKeyInput] = useState<string>('');
  const [keyStatus, setKeyStatus] = useState<KeyStatus>('idle');
  const [keyMessage, setKeyMessage] = useState<string>('');
  const [validKeys, setValidKeys] = useState<string[]>([]);

  const [detectStatus, setDetectStatus] = useState<DetectStatus>('idle');
  const [macAddr, setMacAddr] = useState<string>('');
  const [gatewayIp, setGatewayIp] = useState<string>('');
  const [showManual, setShowManual] = useState<boolean>(false);
  const [manualMac, setManualMac] = useState<string>('');
  const [manualGw, setManualGw] = useState<string>('');

  const pulseAnim = useSharedValue(1);

  useEffect(() => {
    loadVipId();
    pulseAnim.value = withRepeat(
      withTiming(1.04, { duration: 1200, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
  }, []);

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseAnim.value }],
  }));

  async function loadVipId() {
    try {
      let id = await AsyncStorage.getItem('vip_id');
      if (!id) {
        id = generateVipId();
        await AsyncStorage.setItem('vip_id', id);
      }
      setVipId(id);
    } catch {
      setVipId(generateVipId());
    }
  }

  async function fetchKeysFromGithub(): Promise<string[]> {
    try {
      const res = await fetch(GITHUB_KEYS_URL, { cache: 'no-store' });
      if (res.ok) {
        const text = await res.text();
        const keys = text
          .split('\n')
          .map((k) => k.trim())
          .filter(Boolean);
        await AsyncStorage.setItem('valid_keys', JSON.stringify(keys));
        return keys;
      }
    } catch {}
    // Fallback to cached
    try {
      const cached = await AsyncStorage.getItem('valid_keys');
      if (cached) return JSON.parse(cached);
    } catch {}
    return [];
  }

  async function validateKey() {
    const key = keyInput.trim();
    if (!key) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      setKeyMessage('Key ထည့်ပါ');
      return;
    }
    setKeyStatus('checking');
    setKeyMessage('Server မှ စစ်ဆေးနေသည်...');
    Haptics.selectionAsync();

    const keys = await fetchKeysFromGithub();
    setValidKeys(keys);

    if (keys.includes(key)) {
      setKeyStatus('valid');
      setKeyMessage('Key မှန်ကန်သည်!');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      setKeyStatus('invalid');
      setKeyMessage('Key မှားသည် သို့မဟုတ် ရက်လွန်ပြီ');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  }

  async function detectNetwork() {
    setDetectStatus('detecting');
    setMacAddr('');
    setGatewayIp('');
    Haptics.selectionAsync();

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const res = await fetch('http://connectivitycheck.gstatic.com/generate_204', {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: { 'User-Agent': 'Mozilla/5.0 (Android 14) AppleWebKit/537.36' },
      });
      clearTimeout(timeout);

      const location =
        res.headers.get('location') || res.headers.get('Location') || '';
      if (location) {
        const locUrl = new URL(location);
        const params = locUrl.searchParams;
        const gw =
          params.get('gw_address') ||
          params.get('nasip') ||
          params.get('gateway');
        const mac =
          params.get('mac') || params.get('umac') || params.get('client_mac');
        if (gw && mac) {
          setGatewayIp(gw);
          setMacAddr(mac);
          setDetectStatus('found');
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          return;
        }
      }
    } catch {}

    setDetectStatus('failed');
    setShowManual(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
  }

  function openPortal() {
    const mac = macAddr || manualMac;
    const gw = gatewayIp || manualGw;
    if (!mac || !gw) {
      Alert.alert('Error', 'MAC Address နှင့် Gateway IP လိုအပ်သည်');
      return;
    }
    const url = buildPortalUrl(mac, gw);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    Linking.openURL(url).catch(() => Alert.alert('Error', 'Browser ဖွင့်၍ မရပါ'));
  }

  const effectiveMac = macAddr || manualMac;
  const effectiveGw = gatewayIp || manualGw;
  const canOpenPortal = keyStatus === 'valid' && !!effectiveMac && !!effectiveGw;

  const isWeb = Platform.OS === 'web';
  const topPad = isWeb ? 67 : insets.top;
  const botPad = isWeb ? 34 : insets.bottom;

  return (
    <LinearGradient colors={['#040810', '#070b14', '#040810']} style={{ flex: 1 }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.container,
          { paddingTop: topPad + 16, paddingBottom: botPad + 32 },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── LOGO ── */}
        <Animated.View entering={FadeIn.duration(600)} style={styles.logoSection}>
          <Animated.View style={logoStyle}>
            <LinearGradient
              colors={['#00b4ff22', '#00b4ff08', 'transparent']}
              style={styles.logoGlow}
            />
            <View style={styles.logoRow}>
              <MaterialCommunityIcons name="wifi" size={32} color="#00b4ff" />
              <Text style={styles.logoText}>STAR</Text>
              <MaterialCommunityIcons name="wifi" size={32} color="#00b4ff" />
            </View>
          </Animated.View>
          <Text style={styles.logoSub}>Ruijie Network Portal Tool</Text>
          {vipId ? (
            <View style={styles.vipBadge}>
              <GlowDot color="#00e676" />
              <Text style={styles.vipText}>{vipId}</Text>
              <View style={styles.vipTag}>
                <Text style={styles.vipTagText}>VIP</Text>
              </View>
            </View>
          ) : null}
        </Animated.View>

        {/* ── STEP 1: KEY ── */}
        <Animated.View entering={FadeInDown.delay(100).duration(500)} style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.stepBadge}>
              <Text style={styles.stepNum}>1</Text>
            </View>
            <Text style={styles.cardTitle}>VIP Key ထည့်ပါ</Text>
            {keyStatus === 'valid' && (
              <Ionicons name="checkmark-circle" size={20} color="#00e676" />
            )}
          </View>

          <View style={styles.inputRow}>
            <View style={styles.inputWrap}>
              <Ionicons name="key-outline" size={18} color="#4a6b8a" style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="VIP Key ထည့်ပါ..."
                placeholderTextColor="#4a6b8a"
                value={keyInput}
                onChangeText={setKeyInput}
                autoCapitalize="none"
                autoCorrect={false}
                editable={keyStatus !== 'valid'}
              />
            </View>
            <TouchableOpacity
              style={[
                styles.actionBtn,
                keyStatus === 'valid' && { backgroundColor: '#00e67622' },
                keyStatus === 'checking' && { opacity: 0.6 },
              ]}
              onPress={validateKey}
              disabled={keyStatus === 'checking' || keyStatus === 'valid'}
              activeOpacity={0.75}
            >
              {keyStatus === 'checking' ? (
                <ActivityIndicator size="small" color="#00b4ff" />
              ) : keyStatus === 'valid' ? (
                <Ionicons name="checkmark" size={20} color="#00e676" />
              ) : (
                <Text style={styles.actionBtnText}>စစ်ဆေး</Text>
              )}
            </TouchableOpacity>
          </View>

          {keyMessage ? (
            <View style={styles.statusRow}>
              <GlowDot
                color={
                  keyStatus === 'valid'
                    ? '#00e676'
                    : keyStatus === 'invalid'
                    ? '#ff4444'
                    : '#ffb800'
                }
              />
              <Text
                style={[
                  styles.statusText,
                  keyStatus === 'valid' && { color: '#00e676' },
                  keyStatus === 'invalid' && { color: '#ff4444' },
                  keyStatus === 'checking' && { color: '#ffb800' },
                ]}
              >
                {keyMessage}
              </Text>
            </View>
          ) : null}

          <View style={styles.hintRow}>
            <Feather name="info" size={12} color="#4a6b8a" />
            <Text style={styles.hintText}>
              Key မရှိလျှင်: @naymin126653 သို့ ဆက်သွယ်ပါ
            </Text>
          </View>
        </Animated.View>

        {/* ── STEP 2: NETWORK ── */}
        <Animated.View entering={FadeInDown.delay(200).duration(500)} style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={[styles.stepBadge, keyStatus !== 'valid' && styles.stepDisabled]}>
              <Text style={styles.stepNum}>2</Text>
            </View>
            <Text style={[styles.cardTitle, keyStatus !== 'valid' && styles.textDisabled]}>
              Network စစ်ဆေးပါ
            </Text>
            {detectStatus === 'found' && (
              <Ionicons name="checkmark-circle" size={20} color="#00e676" />
            )}
          </View>

          <TouchableOpacity
            style={[
              styles.detectBtn,
              keyStatus !== 'valid' && styles.btnDisabled,
              detectStatus === 'detecting' && { opacity: 0.7 },
            ]}
            onPress={detectNetwork}
            disabled={keyStatus !== 'valid' || detectStatus === 'detecting'}
            activeOpacity={0.75}
          >
            {detectStatus === 'detecting' ? (
              <ActivityIndicator size="small" color="#00b4ff" />
            ) : (
              <MaterialCommunityIcons
                name="wifi-refresh"
                size={18}
                color={keyStatus === 'valid' ? '#00b4ff' : '#4a6b8a'}
              />
            )}
            <Text
              style={[
                styles.detectBtnText,
                keyStatus !== 'valid' && { color: '#4a6b8a' },
              ]}
            >
              {detectStatus === 'detecting'
                ? 'Detecting...'
                : detectStatus === 'found'
                ? 'ထပ်စစ်ဆေး'
                : 'Auto Detect'}
            </Text>
          </TouchableOpacity>

          {detectStatus === 'found' && (
            <Animated.View entering={FadeInDown.duration(400)} style={styles.netResult}>
              <View style={styles.netRow}>
                <MaterialCommunityIcons name="router-network" size={14} color="#4a6b8a" />
                <Text style={styles.netLabel}>Gateway</Text>
                <Text style={styles.netValue}>{gatewayIp}</Text>
              </View>
              <View style={styles.netRow}>
                <MaterialCommunityIcons name="lan" size={14} color="#4a6b8a" />
                <Text style={styles.netLabel}>MAC</Text>
                <Text style={styles.netValue}>{macAddr}</Text>
              </View>
            </Animated.View>
          )}

          {detectStatus === 'failed' && (
            <Animated.View entering={FadeInDown.duration(400)}>
              <View style={styles.statusRow}>
                <GlowDot color="#ff4444" />
                <Text style={[styles.statusText, { color: '#ff4444' }]}>
                  Auto Detect မအောင်မြင်ပါ
                </Text>
              </View>
            </Animated.View>
          )}

          {/* Manual toggle */}
          {keyStatus === 'valid' && (
            <TouchableOpacity
              style={styles.manualToggle}
              onPress={() => setShowManual((v) => !v)}
              activeOpacity={0.7}
            >
              <Feather
                name={showManual ? 'chevron-up' : 'chevron-down'}
                size={14}
                color="#4a6b8a"
              />
              <Text style={styles.manualToggleText}>
                {showManual ? 'Manual Input ပိတ်' : 'Manual Input ဖွင့်'}
              </Text>
            </TouchableOpacity>
          )}

          {showManual && (
            <Animated.View entering={FadeInDown.duration(300)} style={styles.manualSection}>
              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="router-network"
                  size={16}
                  color="#4a6b8a"
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.input}
                  placeholder="Gateway IP (e.g. 192.168.1.1)"
                  placeholderTextColor="#4a6b8a"
                  value={manualGw}
                  onChangeText={setManualGw}
                  keyboardType="default"
                  autoCapitalize="none"
                />
              </View>
              <View style={[styles.inputWrap, { marginTop: 10 }]}>
                <MaterialCommunityIcons
                  name="lan"
                  size={16}
                  color="#4a6b8a"
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.input}
                  placeholder="MAC Address (e.g. aa:bb:cc:dd:ee:ff)"
                  placeholderTextColor="#4a6b8a"
                  value={manualMac}
                  onChangeText={setManualMac}
                  autoCapitalize="none"
                />
              </View>
            </Animated.View>
          )}
        </Animated.View>

        {/* ── STEP 3: OPEN PORTAL ── */}
        <Animated.View entering={FadeInDown.delay(300).duration(500)} style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={[styles.stepBadge, !canOpenPortal && styles.stepDisabled]}>
              <Text style={styles.stepNum}>3</Text>
            </View>
            <Text style={[styles.cardTitle, !canOpenPortal && styles.textDisabled]}>
              Portal ဖွင့်ပါ
            </Text>
          </View>

          {canOpenPortal && (
            <Animated.View entering={FadeInDown.duration(400)} style={styles.netResult}>
              <View style={styles.netRow}>
                <MaterialCommunityIcons name="router-network" size={14} color="#4a6b8a" />
                <Text style={styles.netLabel}>Gateway</Text>
                <Text style={styles.netValue}>{effectiveGw}</Text>
              </View>
              <View style={styles.netRow}>
                <MaterialCommunityIcons name="lan" size={14} color="#4a6b8a" />
                <Text style={styles.netLabel}>MAC</Text>
                <Text style={styles.netValue}>{effectiveMac}</Text>
              </View>
            </Animated.View>
          )}

          <TouchableOpacity
            style={[styles.portalBtn, !canOpenPortal && styles.btnDisabled]}
            onPress={openPortal}
            disabled={!canOpenPortal}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={canOpenPortal ? ['#00b4ff', '#0080cc'] : ['#152040', '#0d1728']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.portalBtnGrad}
            >
              <MaterialCommunityIcons
                name="web"
                size={22}
                color={canOpenPortal ? '#000' : '#4a6b8a'}
              />
              <Text
                style={[
                  styles.portalBtnText,
                  !canOpenPortal && { color: '#4a6b8a' },
                ]}
              >
                Portal ဖွင့်မည်
              </Text>
            </LinearGradient>
          </TouchableOpacity>

          {!canOpenPortal && (
            <Text style={styles.hintText}>
              {keyStatus !== 'valid'
                ? 'Step 1: Key စစ်ဆေးပါ'
                : 'Step 2: Network စစ်ဆေးပါ'}
            </Text>
          )}
        </Animated.View>

        {/* ── FOOTER ── */}
        <Animated.View entering={FadeInDown.delay(400).duration(500)} style={styles.footer}>
          <View style={styles.footerRow}>
            <FontAwesome5 name="telegram-plane" size={16} color="#00b4ff" />
            <Text style={styles.footerText}>@naymin126653 | @Leearma6</Text>
          </View>
          <View style={styles.footerRow}>
            <MaterialCommunityIcons name="broadcast" size={14} color="#4a6b8a" />
            <Text style={[styles.footerText, { color: '#4a6b8a', fontSize: 11 }]}>
              t.me/starlinkcodebypass
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </LinearGradient>
  );
}

function makeStyles(colors: ReturnType<typeof import('@/hooks/useColors').useColors>) {
  return StyleSheet.create({
    container: {
      paddingHorizontal: 20,
      alignItems: 'stretch',
    },
    logoSection: {
      alignItems: 'center',
      marginBottom: 28,
    },
    logoGlow: {
      position: 'absolute',
      width: 200,
      height: 200,
      borderRadius: 100,
      top: -40,
      left: '50%' as any,
      marginLeft: -100,
    },
    logoRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
    },
    logoText: {
      fontSize: 48,
      fontFamily: 'Inter_700Bold',
      color: '#00b4ff',
      letterSpacing: 8,
    },
    logoSub: {
      fontSize: 12,
      fontFamily: 'Inter_400Regular',
      color: '#4a6b8a',
      letterSpacing: 2,
      marginTop: 4,
      textTransform: 'uppercase' as const,
    },
    vipBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginTop: 12,
      backgroundColor: '#0d1728',
      paddingHorizontal: 14,
      paddingVertical: 6,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: '#152040',
    },
    vipText: {
      fontSize: 13,
      fontFamily: 'Inter_600SemiBold',
      color: '#a0c4e8',
      letterSpacing: 1,
    },
    vipTag: {
      backgroundColor: '#00b4ff22',
      paddingHorizontal: 8,
      paddingVertical: 2,
      borderRadius: 8,
    },
    vipTagText: {
      fontSize: 10,
      fontFamily: 'Inter_700Bold',
      color: '#00b4ff',
      letterSpacing: 1,
    },
    card: {
      backgroundColor: '#0d1728',
      borderRadius: 16,
      borderWidth: 1,
      borderColor: '#152040',
      padding: 18,
      marginBottom: 14,
    },
    cardHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      marginBottom: 14,
    },
    stepBadge: {
      width: 26,
      height: 26,
      borderRadius: 13,
      backgroundColor: '#00b4ff22',
      borderWidth: 1,
      borderColor: '#00b4ff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    stepDisabled: {
      backgroundColor: '#152040',
      borderColor: '#152040',
    },
    stepNum: {
      fontSize: 12,
      fontFamily: 'Inter_700Bold',
      color: '#00b4ff',
    },
    cardTitle: {
      fontSize: 15,
      fontFamily: 'Inter_600SemiBold',
      color: '#e0f0ff',
      flex: 1,
    },
    textDisabled: {
      color: '#4a6b8a',
    },
    inputRow: {
      flexDirection: 'row',
      gap: 10,
      alignItems: 'center',
    },
    inputWrap: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#070b14',
      borderRadius: 10,
      borderWidth: 1,
      borderColor: '#152040',
      paddingHorizontal: 12,
      height: 44,
    },
    inputIcon: {
      marginRight: 8,
    },
    input: {
      flex: 1,
      fontSize: 14,
      fontFamily: 'Inter_400Regular',
      color: '#e0f0ff',
      height: 44,
    },
    actionBtn: {
      width: 80,
      height: 44,
      borderRadius: 10,
      backgroundColor: '#00b4ff22',
      borderWidth: 1,
      borderColor: '#00b4ff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    actionBtnText: {
      fontSize: 13,
      fontFamily: 'Inter_600SemiBold',
      color: '#00b4ff',
    },
    statusRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginTop: 10,
    },
    statusText: {
      fontSize: 13,
      fontFamily: 'Inter_500Medium',
      color: '#ffb800',
    },
    hintRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      marginTop: 10,
    },
    hintText: {
      fontSize: 11,
      fontFamily: 'Inter_400Regular',
      color: '#4a6b8a',
      marginTop: 6,
    },
    detectBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      height: 44,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: '#00b4ff',
      backgroundColor: '#00b4ff11',
    },
    detectBtnText: {
      fontSize: 14,
      fontFamily: 'Inter_600SemiBold',
      color: '#00b4ff',
    },
    btnDisabled: {
      borderColor: '#152040',
      backgroundColor: '#070b14',
    },
    netResult: {
      backgroundColor: '#070b14',
      borderRadius: 10,
      padding: 12,
      marginTop: 10,
      gap: 8,
    },
    netRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    netLabel: {
      fontSize: 12,
      fontFamily: 'Inter_500Medium',
      color: '#4a6b8a',
      width: 60,
    },
    netValue: {
      fontSize: 13,
      fontFamily: 'Inter_600SemiBold',
      color: '#00b4ff',
      flex: 1,
    },
    manualToggle: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      marginTop: 12,
      alignSelf: 'flex-start' as const,
    },
    manualToggleText: {
      fontSize: 12,
      fontFamily: 'Inter_500Medium',
      color: '#4a6b8a',
    },
    manualSection: {
      marginTop: 10,
      gap: 0,
    },
    portalBtn: {
      borderRadius: 12,
      overflow: 'hidden' as const,
      marginTop: 4,
    },
    portalBtnGrad: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      height: 52,
    },
    portalBtnText: {
      fontSize: 16,
      fontFamily: 'Inter_700Bold',
      color: '#000000',
      letterSpacing: 0.5,
    },
    footer: {
      alignItems: 'center',
      gap: 6,
      marginTop: 10,
    },
    footerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    footerText: {
      fontSize: 12,
      fontFamily: 'Inter_500Medium',
      color: '#00b4ff',
    },
  });
}
