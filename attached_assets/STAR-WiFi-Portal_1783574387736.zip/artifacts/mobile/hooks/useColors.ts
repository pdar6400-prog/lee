import { useColorScheme } from 'react-native';
import colors from '@/constants/colors';

type ColorPalette = typeof colors.light;

/**
 * Returns the design tokens for the current color scheme.
 * Falls back to the light palette when no dark key is defined.
 */
export function useColors(): ColorPalette & { radius: number } {
  const scheme = useColorScheme();
  const palette: ColorPalette =
    scheme === 'dark' && 'dark' in colors
      ? (colors as { light: ColorPalette; dark: ColorPalette; radius: number }).dark
      : colors.light;
  return { ...palette, radius: colors.radius };
}
